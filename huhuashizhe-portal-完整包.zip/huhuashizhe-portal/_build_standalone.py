# -*- coding: utf-8 -*-
"""把 huhuashizhe-portal/index.html 打包成单文件自包含 HTML，输出到桌面。"""
import base64
import re
import zipfile
from pathlib import Path

SRC = Path(r"C:\Users\MECHREVO\Downloads\huhuashizhe-portal")
OUT = Path(r"C:\Users\MECHREVO\Desktop")
OUT.mkdir(parents=True, exist_ok=True)

MIME = {
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
    ".webp": "image/webp", ".svg": "image/svg+xml", ".gif": "image/gif",
    ".ico": "image/x-icon", ".mp4": "video/mp4",
}

_cache = {}


def to_uri(rel):
    p = SRC / rel
    if not p.is_file():
        return None
    key = str(p)
    if key in _cache:
        return _cache[key]
    mime = MIME.get(p.suffix.lower(), "application/octet-stream")
    uri = "data:" + mime + ";base64," + base64.b64encode(p.read_bytes()).decode("ascii")
    _cache[key] = uri
    return uri


ASSET_RE = re.compile(r"(?:\./)?assets/[A-Za-z0-9_\-./]+\.[A-Za-z0-9]{2,5}")


def inline_assets(text):
    missing = []

    def rep(m):
        rel = m.group(0)
        if rel.startswith("./"):
            rel = rel[2:]
        uri = to_uri(rel)
        if uri is None:
            missing.append(rel)
            return m.group(0)
        return uri

    return ASSET_RE.sub(rep, text), missing


print("[1/4] 读取 index.html")
html = (SRC / "index.html").read_text(encoding="utf-8", errors="replace")
print("      原始大小: %d 字节" % len(html))

html2, missing = inline_assets(html)
print("[2/4] 内联本地图片: 命中 %d 个 data URI，缺失 %d 个" % (len(_cache), len(missing)))
if missing:
    print("      缺失: %s" % sorted(set(missing)))

quad_note = "未找到 quadcopter.html"
quad = SRC / "quadcopter.html"
if quad.is_file():
    qtext = quad.read_text(encoding="utf-8", errors="replace")
    qtext2, qmiss = inline_assets(qtext)
    qb64 = base64.b64encode(qtext2.encode("utf-8")).decode("ascii")
    JS = (
        '<script>window.__QUAD_B64__="' + qb64 + '";</script>\n'
        '<script>(function(){'
        'function openQuad(){'
        'var s=atob(window.__QUAD_B64__),n=s.length,a=new Uint8Array(n),i;'
        'for(i=0;i<n;i++){a[i]=s.charCodeAt(i);}'
        'var u=URL.createObjectURL(new Blob([a],{type:"text/html;charset=utf-8"}));'
        'var w=window.open(u,"_blank");'
        'if(!w){alert("浏览器拦截了弹出窗口，请允许弹出窗口后重试。");}'
        '}'
        'document.addEventListener("click",function(ev){'
        'var el=ev.target;'
        'while(el&&el.tagName!=="A"){el=el.parentElement;}'
        'if(el&&/quadcopter\\.html$/i.test(el.getAttribute("href")||"")){'
        'ev.preventDefault();openQuad();}'
        '},true);'
        '})();</script>\n'
    )
    if "</body>" in html2:
        html2 = html2.replace("</body>", JS + "</body>", 1)
    else:
        html2 = html2 + JS
    quad_note = "已内嵌 quadcopter.html（原 %d B -> base64 %d B），子页缺失资源 %s" % (
        len(qtext), len(qb64), qmiss if qmiss else "无")

out_html = OUT / "huhuashizhe-portal-单文件版.html"
out_html.write_text(html2, encoding="utf-8")
print("[3/4] 写出单文件: %s (%d 字节 / %.2f MB)" % (out_html, out_html.stat().st_size, out_html.stat().st_size / 1048576.0))

zip_path = OUT / "huhuashizhe-portal-完整包.zip"
count = 0
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for p in SRC.rglob("*"):
        if p.is_dir():
            continue
        if ".git" in p.parts:
            continue
        z.write(p, str(Path("huhuashizhe-portal") / p.relative_to(SRC)))
        count = count + 1
print("[4/4] 写出完整包: %s (%d 个文件 / %.2f MB)" % (zip_path, count, zip_path.stat().st_size / 1048576.0))

left = html2.count('assets/')
http_n = html2.count('http://') + html2.count('https://')
print("--- 自检 ---")
print("残留 assets/ 引用: %d（应为 0）" % left)
print("外部 http(s) 链接数量: %d（在线时正常可用）" % http_n)
print("data URI 数量: %d，总内联资源: %d 个文件" % (html2.count('data:image'), len(_cache)))
print(quad_note)
