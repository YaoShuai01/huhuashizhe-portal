@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ================================================
echo   护花使者门户 - 一键推送到 GitHub
echo ================================================
echo.
echo [当前提交]
git log -1 --oneline
echo.
echo [远端地址]
git remote get-url origin
echo.
echo [开始推送]
echo   如果弹出 GitHub 登录窗口，请用拥有
echo   YaoShuai01/huhuashizhe-portal 写权限的账号登录。
echo   注意：不是 Liuge686（那个账号对这个仓库只有读权限）。
echo.
git push origin HEAD:main
if errorlevel 1 goto failed
echo.
echo [推送成功] 远端 main 现在是：
git log origin/main -1 --oneline
echo.
echo [线上地址] Pages 约 1-2 分钟生效，强制刷新 Ctrl+F5：
echo   https://yaoshuai01.github.io/huhuashizhe-portal/
echo   https://yaoshuai01.github.io/huhuashizhe-portal/quadcopter.html
start "" "https://yaoshuai01.github.io/huhuashizhe-portal/"
goto end

:failed
echo.
echo [推送失败] 按下列错误对号入座：
echo.
echo   403 / Permission denied
echo     -^> 当前登录账号对该仓库没有 Write 权限。
echo        解决 A：让仓库所有者在 Settings - Collaborators 里把当前账号加成 Write。
echo        解决 B：在你自己的账号下 Fork 该仓库，然后推 fork。
echo.
echo   Connection was reset / timed out
echo     -^> 当前网络到 github.com:443 的 git 通道被重置。
echo        解决：换网络、开代理后重试；或改用 PAT 走 api.github.com。
echo.
echo   本次未推送任何内容，本地提交完好：
git log -1 --oneline
echo.
pause
exit /b 1

:end
echo.
pause
endlocal
